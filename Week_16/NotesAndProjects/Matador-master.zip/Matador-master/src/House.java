public class House extends Building {

    public House(int id, String label, int cost, int income) {
        super(id, label, cost, income);
    }
}
