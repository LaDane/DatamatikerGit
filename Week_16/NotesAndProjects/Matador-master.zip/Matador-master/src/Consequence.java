public class Consequence extends Field {

    public Consequence(int id, String label) {
        super(id, label);
    }

    @Override
    public Action getAction() {


        return null;
    }


}
