public interface Purchasable {
    void purchase();
}
