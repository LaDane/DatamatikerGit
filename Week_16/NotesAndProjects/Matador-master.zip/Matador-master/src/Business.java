public class Business extends Property {

    public Business(int id, String label, int cost, int income, int seriesID) {
        super(id, label, cost, income,  seriesID);
    }
}
