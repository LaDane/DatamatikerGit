public class Hotel extends Building {

    public Hotel(int id, String label, int cost, int income) {
        super(id, label, cost, income);
    }
}
