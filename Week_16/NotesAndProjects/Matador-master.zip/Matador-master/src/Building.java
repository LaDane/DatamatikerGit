public class Building implements Purchasable{

    public Building(int id, String label, int cost, int income) {

    }

    @Override
    public void purchase() {

    }
}
